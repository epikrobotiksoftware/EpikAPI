1- roscore
2- roslaunch rosbridge_server rosbridge_websocket.launch 
3- rosrun robot publish_robot_state.py
// services
// inside catkin_ws/src 
4- roslaunch for_arslan start.launch 